package com.example.facebook
import android.content.Intent
import android.graphics.Color
import android.media.Image
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.PopupWindow
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.facebook.MainActivity.Lista
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout

class RegistroActivity : AppCompatActivity() {
    lateinit var registrar: MaterialButton
    lateinit var usuario: EditText
    lateinit var contraseña: EditText
    lateinit var confirmar: EditText
    lateinit var nombre: EditText
    lateinit var usuarioIniciar: String
    lateinit var apellidos: EditText
    lateinit var cancelar: ImageButton
    val miLista = Lista.cuentas
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.registro_activity)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inicializar()
        evento()
        mostrar()
    }

    fun inicializar() {

        usuario = findViewById(R.id.usuario_crear)
        contraseña = findViewById(R.id.contraseña_crear)
        confirmar = findViewById(R.id.confirmar_contraseñaCrear)
        registrar = findViewById<MaterialButton>(R.id.crearCuenta_boton)
        nombre = findViewById(R.id.nombre_crear)
        apellidos = findViewById(R.id.apellidos_crear)
        usuarioIniciar = intent.getStringExtra("USUARIO").toString()
        cancelar = findViewById(R.id.cancelar)


    }

    private fun mostrar() {

        //se coloca el usuario introducido en login al ser erroneo para ahorrar tiempo
        if (usuarioIniciar != "null"){
            usuario.setText(usuarioIniciar).toString()
        }

    }

    fun evento() {

        // inicializa los bordes de los editText
        var bordeusuario = findViewById<TextInputLayout>(R.id.usuarioC)
        var bordenombre = findViewById<TextInputLayout>(R.id.nombreC)
        var bordeapellidos = findViewById<TextInputLayout>(R.id.apellidosC)
        var bordecontraseña = findViewById<TextInputLayout>(R.id.contraseñaC)
        var bordeconfirmar = findViewById<TextInputLayout>(R.id.confirmarcontraseñaC)

        registrar.setOnClickListener {
            //hace que los bordes de los editText sean los predeterminados a la hora de presionar el boton de crear cuenta
            bordeusuario.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bordenombre.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bordeapellidos.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bordeconfirmar.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bordecontraseña.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)

            //inicializa variables y obtiene los datos de los editText para la validacion de estos
            var user = usuario.text.toString()
            var contraseña1 = contraseña.text.toString()
            var confirmarC = confirmar.text.toString()
            var nombreU = nombre.text.toString()
            var apellidosU = apellidos.text.toString()
            var contador:Int = miLista.size-1
            var igual:String = ""

            // valida que el usuario no esté vacio
            if (user == ""){
                Toast.makeText(this, "campo correo vacio", Toast.LENGTH_SHORT).show()
                bordeusuario.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
            }else {
                // valida que el nombre no esté vacio
                if (nombreU == "") {
                    Toast.makeText(this, "campo nombre vacio", Toast.LENGTH_SHORT).show()
                    bordenombre.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                } else {
                    //valida que el campo apellidos no esté vacio
                    if (apellidosU == ""){
                        Toast.makeText(this, "campo apellidos vacio", Toast.LENGTH_SHORT).show()
                        bordeapellidos.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                    }
                    else {
                        //valida que el campo contraseña no esté vacio
                        if (contraseña1 == "") {
                            Toast.makeText(this, "campo contraseña vacio", Toast.LENGTH_SHORT)
                                .show()
                            bordecontraseña.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                        } else {
                            // valida que el usuario tenga el formato de correo
                            if (user.endsWith("@gmail.com")) {

                                // busca que el usuario del editText concuerde con algun usuario de la lista de cuentas
                                for (i in 0..contador) {
                                    if (miLista[i][0] == user) {
                                        igual = "SI"
                                    }
                                }
                                //valida si se encontro el usuario
                                if (igual == "SI") {
                                    Toast.makeText(this, "usuario ya existe", Toast.LENGTH_SHORT)
                                        .show()
                                    bordeusuario.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)

                                } else {
                                    // valida que la contraseña y la confirmacion sean la misma
                                    if (confirmarC != contraseña1) {
                                        Toast.makeText(
                                            this,
                                            "las contraseñas no coinciden",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        bordecontraseña.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                                        bordeconfirmar.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)

                                    } else {
                                        //crea una variable para guardar todos esos datos dados en editText en una mutableList para guardarlos en la lista de cuentas
                                        var cuenta_creada =
                                            mutableListOf(user, contraseña1, nombreU,apellidosU)
                                        miLista.add(cuenta_creada)

                                        //el codigo para llamar la ventana emergente
                                        val inflater = LayoutInflater.from(this)
                                        val vista_emergente = inflater.inflate(R.layout.activity_ventana_emergente_registro,null)

                                        val popup_ventana = PopupWindow(vista_emergente, ViewGroup.LayoutParams.MATCH_PARENT,
                                            ViewGroup.LayoutParams.MATCH_PARENT, true)
                                        popup_ventana.isOutsideTouchable = false  //evita que la ventana se cierre al tocar afuera de esta

                                        popup_ventana.showAtLocation(vista_emergente, Gravity.CENTER,0,0)

                                        val botonCerrarVentana =  vista_emergente.findViewById<Button>(R.id.boton_ventana)
                                        botonCerrarVentana.setOnClickListener {
                                            launchIniciarSesion(user)
                                        }
                                        //termina el codigo para llamar ventana emergente
                                    }

                                }
                            } else {
                                Toast.makeText(
                                    this,
                                    "este no es un correo valido",
                                    Toast.LENGTH_SHORT
                                ).show()
                                bordeusuario.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                            }

                        }
                    }
                }
            }
        }

        //el evento de cancelar la creacion de cuenta
        cancelar.setOnClickListener {
            var user:String = ""
            launchIniciarSesion(user)
        }

    }

    fun launchIniciarSesion(user:String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("usuario", user)
        startActivity(intent)
    }

}