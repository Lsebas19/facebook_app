package com.example.facebook
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.facebook.MainActivity.Iniciada
import com.example.facebook.inicio.Publicaciones

class CrearPublicacion : AppCompatActivity() {
    lateinit var nombre_cuenta : TextView
    lateinit var texto_publicacion: EditText
    lateinit var publicar : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_crear_publicacion)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inicializar()
        mostrar()
        eventos()
    }
    fun inicializar(){
        nombre_cuenta = findViewById(R.id.nombre_cuenta_publicacion_crear)
        texto_publicacion = findViewById(R.id.texto_publicacion)
        publicar = findViewById(R.id.publicar)
    }

    fun mostrar(){
        var nombre = Iniciada.cuenta_iniciada[0][2]
        var apellido = Iniciada.cuenta_iniciada[0][3]
        var nombre_completo = "$nombre $apellido"
        nombre_cuenta.text = nombre_completo
    }

    fun eventos(){

        publicar.setOnClickListener {

            var texto = texto_publicacion.text.toString()

            if (texto != ""){
                var usuario = Iniciada.cuenta_iniciada[0][0]
                var nombre = Iniciada.cuenta_iniciada[0][2]
                var apellido = Iniciada.cuenta_iniciada[0][3]

                var publicacionsita: MutableList<String> = mutableListOf<String>(usuario,nombre,apellido,texto)
                Publicaciones.publicaciones_hechas.add(publicacionsita)
                launchInicio()
            }
        }
    }
    fun launchInicio() {
        val intent = Intent(this, inicio::class.java)
        startActivity(intent)
    }
}