package com.example.facebook

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.facebook.MainActivity.Iniciada

class inicio : AppCompatActivity() {
    lateinit var nombre_inicio: TextView
    lateinit var correo: TextView
    lateinit var apellido: TextView
    lateinit var cerrar_sesion: ImageButton
    lateinit var publicacion: Button


    object Publicaciones{
        var publicaciones_hechas : MutableList<MutableList<String>> = mutableListOf()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.interfaz_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inicializar()
        mostrar()
        eventos()

    }


    //muestra los datos de la cuenta iniciada en la pestaña principal
    private fun mostrar(){
        nombre_inicio.text = Iniciada.cuenta_iniciada[0][2]
        correo.text =Iniciada.cuenta_iniciada[0][0]
        apellido.text = Iniciada.cuenta_iniciada[0][3]

        //publicaciones

        var contador = Publicaciones.publicaciones_hechas.size

        if (contador > 0){
            var fondo_publicacion = findViewById<LinearLayout>(R.id.publicacion_inicio)
            fondo_publicacion.setBackgroundColor(ContextCompat.getColor(this,R.color.temaOscuro))
            var nombre_publicacion = findViewById<TextView>(R.id.nombre_cuenta_publicacion)
            var apellido_publicacion = findViewById<TextView>(R.id.apellido_cuenta_publicacion)
            var texto_publicacion = findViewById<TextView>(R.id.descripcion_publicacion)

            nombre_publicacion.text = Publicaciones.publicaciones_hechas[0][1]
            apellido_publicacion.text = Publicaciones.publicaciones_hechas[0][2]
            texto_publicacion.text = Publicaciones.publicaciones_hechas[0][3]

        }

    }

    fun inicializar (){
        nombre_inicio = findViewById(R.id.nombre_cuenta)
        correo = findViewById(R.id.descripcion)
        apellido = findViewById(R.id.apellido_cuenta)
        cerrar_sesion = findViewById(R.id.cerrar_sesion)
        publicacion = findViewById(R.id.crear_publicacion)

    }

    fun eventos(){
        // evento para cerrar sesion
        cerrar_sesion.setOnClickListener {
            Iniciada.cuenta_iniciada.removeAt(0)
            launchLogin()
        }
        publicacion.setOnClickListener {
            launchCrearPublicacion()
        }
    }

    fun launchGuardadas(){
        val intent = Intent(this, cuentasGuardadas::class.java)
        startActivity(intent)
    }

    fun launchCrearPublicacion(){
        val intent = Intent(this, CrearPublicacion::class.java)
        startActivity(intent)
    }
    fun launchLogin(){
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
    }
}