package com.example.facebook

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.PopupWindow
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.facebook.MainActivity.Guardadas
import com.google.android.material.button.MaterialButton
import com.example.facebook.MainActivity.Iniciada
import androidx.core.content.ContextCompat

class cuentasGuardadas : AppCompatActivity() {
    lateinit var login : MaterialButton
    lateinit var usuario1 : MaterialButton
    lateinit var usuario2 : MaterialButton
    lateinit var crearCuenta: MaterialButton
    lateinit var btn_borrar_guardadas : ImageButton
    var misCuentas = Guardadas.cuentas_guardadas
    var posicion = misCuentas.size-1
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cuentas_guardadas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inicializar()
        mostrar()
        eventos()
    }
    fun inicializar(){

        usuario1 = findViewById<MaterialButton>(R.id.cuenta1)
        usuario2 = findViewById<MaterialButton>(R.id.cuenta2)
        login = findViewById<MaterialButton>(R.id.boton_login)
        crearCuenta = findViewById<MaterialButton>(R.id.crearCuentaGuardados)
        btn_borrar_guardadas = findViewById(R.id.opciones_eliminar_guardadas)

    }

    fun mostrar(){
        //inicializa variables
        var contador:Int = misCuentas.size
        var nombre1 = misCuentas[posicion][2]
        var apellido1 = misCuentas[posicion][3]
        var nombre_completo1 = "$nombre1 $apellido1"

        // verifica que el numero de cuentas que hay guardadas, si solo es una agrega datos y si son dos crea el espacio para mostrar la otra cuenta
        if (contador < 2){

            usuario1.text = nombre_completo1

        }else{

            usuario1.text = nombre_completo1

            var nombre2 = misCuentas[posicion-1][2]
            var apellido2 = misCuentas[posicion-1][3]
            var nombre_completo2 = "$nombre2 $apellido2"

            //agrega el nombre de la cuenta, imagen y bordes a el campo del boton
            usuario2.text = nombre_completo2
            usuario2.strokeColor = ColorStateList.valueOf(ContextCompat.getColor(this,R.color.grisEditText))
            usuario2.icon = ContextCompat.getDrawable(this,R.drawable.cuenta_icono)
            usuario2.iconSize = 200
            usuario2.iconTint = ColorStateList.valueOf(ContextCompat.getColor(this,R.color.grisIcono))

        }

    }

    fun eventos(){
        // al presionar boton agregar cuenta a lista de iniciada y mandar a interfaz principal
        usuario1.setOnClickListener {
            Iniciada.cuenta_iniciada.add(misCuentas[posicion])
            launchInicio()
        }

        usuario2.setOnClickListener {
            Iniciada.cuenta_iniciada.add(misCuentas[posicion-1])
            launchInicio()
        }

        //eventos de botones
        login.setOnClickListener {
            launchLogin()
        }

        crearCuenta.setOnClickListener {
            launchCrearCuenta()
        }

        //ventana emergente para eliminar cuentas guardadas

        btn_borrar_guardadas.setOnClickListener {
            val inflater = LayoutInflater.from(this)
            val vista_emergente = inflater.inflate(R.layout.activity_borra_cuentas_guardadas,null)
            val popup_ventana = PopupWindow(vista_emergente, ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT, true)
            popup_ventana.isOutsideTouchable = false  //evita que la ventana se cierre al tocar afuera de esta
            popup_ventana.showAtLocation(vista_emergente, Gravity.CENTER,0,0)

            val btn_cerrar_eliminar = vista_emergente.findViewById<ImageButton>(R.id.salir_eliminar_guardados)
            val btn_borrar_cuentas = vista_emergente.findViewById<MaterialButton>(R.id.eliminar_guardados)

            //salir de la ventana emergente
            btn_cerrar_eliminar.setOnClickListener {
                popup_ventana.dismiss()
            }

            //borrar las cuentas guardadas
            btn_borrar_cuentas.setOnClickListener {
                var tamaño = Guardadas.cuentas_guardadas.size-1
                for (i in 0..tamaño){
                    Guardadas.cuentas_guardadas.removeAt(0)
                }
                launchLogin()
            }

        }

    }

    fun launchInicio(){
        val intent = Intent(this, inicio::class.java)

        startActivity(intent)

    }

    fun launchLogin(){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun launchCrearCuenta() {
        val intent = Intent(this, RegistroActivity::class.java)
        startActivity(intent)
    }

}

