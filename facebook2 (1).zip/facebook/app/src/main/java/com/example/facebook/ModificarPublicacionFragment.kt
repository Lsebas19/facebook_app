package com.example.facebook

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.facebook.databinding.FragmentModificarPublicacionBinding
import com.example.facebook.models.ModelPublicaciones
import com.example.facebook.InicioActivity.ContadorFragments


class ModificarPublicacionFragment : Fragment() {

    private var  _bindingActualizar: FragmentModificarPublicacionBinding? = null
    private val bindingActualizar get() = _bindingActualizar!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _bindingActualizar = FragmentModificarPublicacionBinding.inflate(inflater,container,false)
        return bindingActualizar.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        evento(view)
        ActualizarPublicacion(InicioActivity.Modificar.publi, InicioActivity.ModificarPosicion.posicion)
    }

    fun ActualizarPublicacion(publicacion: ModelPublicaciones,position:Int){
        // aqui le manda los datos que recogio la variable publicacion a los editText para modificar
        bindingActualizar.tituloPublicarA.setText(publicacion.tituloPublicacion)
        bindingActualizar.descripcionPublicarA.setText(publicacion.descripcionPublicacion)

        //si el campo de imagen contiene un 1 es porque no habia imagen asi que se elimina para que quede vacio
        if (publicacion.imagenPublicacion == "1"){
            bindingActualizar.imagenPublicarA.setText("")
        }else{
            bindingActualizar.imagenPublicarA.setText(publicacion.imagenPublicacion)
        }

        var imagen:String = ""
        //accion del boton actualizar
        bindingActualizar.actualizar.setOnClickListener {

            //validar si el campo de imagen está vacio y si es asi enviar un dato
            if (bindingActualizar.imagenPublicarA.text.toString() == ""){
                imagen = "1"
            }else{
                imagen = bindingActualizar.imagenPublicarA.text.toString()
            }
            /* esto hace que se ejecute una funcion de la actividad que contiene el fragment enviandole los datos
            de la publicacion para que sea en la actividad que se agregen
            */
            if(bindingActualizar.tituloPublicarA.text.toString() == ""){
                bindingActualizar.tituloPublicarA.background = ContextCompat.getDrawable(requireContext(),R.drawable.activity_campo_vacio_publicar)
                Toast.makeText(requireContext(), "campo vacio", Toast.LENGTH_SHORT).show()
            }else{
                if(bindingActualizar.descripcionPublicarA.text.toString() == ""){
                    bindingActualizar.descripcionPublicarA.background = ContextCompat.getDrawable(requireContext(),R.drawable.activity_campo_vacio_publicar)
                    Toast.makeText(requireContext(), "campo vacio", Toast.LENGTH_SHORT).show()
                }else {
                    (activity as? InicioActivity)?.modificarPubli(
                        publicacion.nombrePublicacion,
                        publicacion.apellidoPublicacion,
                        bindingActualizar.tituloPublicarA.text.toString(),
                        bindingActualizar.descripcionPublicarA.text.toString(),
                        imagen,
                        position
                    )
                    //esta linea cierra el fragment
                    ContadorFragments.todos = 0
                    ContadorFragments.contadorModificar = 0
                    parentFragmentManager.beginTransaction().hide(this).commit()
                }
            }
        }
    }

    fun evento(view: View) {
        bindingActualizar.botonRetrocesoPublicacionA.setOnClickListener {
            ContadorFragments.todos = 0
            ContadorFragments.contadorModificar = 0
            parentFragmentManager.beginTransaction().hide(this).commit()
        }
    }

}