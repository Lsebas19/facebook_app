package com.example.facebook

import android.os.Bundle

import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.facebook.InicioActivity.ContadorFragments


import com.example.facebook.databinding.FragmentCrearPublicacionBinding



class CrearPublicacionFragment : Fragment() {
    private var  _binding: FragmentCrearPublicacionBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }

    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentCrearPublicacionBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        evento(view)
    }


    fun evento(view: View){
        binding.botonRetrocesoPublicacion.setOnClickListener {
            //reiniciar el contador para que no salgan mas fragments de los que deberian
            ContadorFragments.contadorCrear = 0
            ContadorFragments.todos = 0
            parentFragmentManager.beginTransaction().hide(this).commit()
        }

        binding.publicarBoton.setOnClickListener {
            binding.tituloPublicar.background = null
            if(binding.tituloPublicar.text.toString() == ""){
                binding.tituloPublicar.background = ContextCompat.getDrawable(requireContext(),R.drawable.activity_campo_vacio_publicar)
                Toast.makeText(requireContext(), "campo vacio", Toast.LENGTH_SHORT).show()
            }else{
                if(binding.descripcionPublicar.text.toString() == ""){
                    binding.descripcionPublicar.background = ContextCompat.getDrawable(requireContext(),R.drawable.activity_campo_vacio_publicar)
                    Toast.makeText(requireContext(), "campo vacio", Toast.LENGTH_SHORT).show()
                }else{
                    if(binding.imagenPublicar.text.toString() == ""){
                        (activity as? InicioActivity)?.agregarPubli(MainActivity.Iniciada.cuenta_iniciada[0][2],
                            MainActivity.Iniciada.cuenta_iniciada[0][3],
                            binding.tituloPublicar.text.toString(),
                            binding.descripcionPublicar.text.toString(),
                            "1")
                        ContadorFragments.contadorCrear = 0
                        ContadorFragments.todos = 0
                        parentFragmentManager.beginTransaction().hide(this).commit()

                    }else{
                        (activity as? InicioActivity)?.agregarPubli(MainActivity.Iniciada.cuenta_iniciada[0][2],
                            MainActivity.Iniciada.cuenta_iniciada[0][3],
                            binding.tituloPublicar.text.toString(),
                            binding.descripcionPublicar.text.toString(),
                            binding.imagenPublicar.text.toString())
                        ContadorFragments.contadorCrear = 0
                        ContadorFragments.todos = 0
                        parentFragmentManager.beginTransaction().hide(this).commit()
                    }
                }
            }


        }

    }


}