package com.example.facebook.models

data class ModelPublicaciones (
    var nombrePublicacion: String,
    var apellidoPublicacion:String,
    var tituloPublicacion: String,
    var descripcionPublicacion : String,
    var imagenPublicacion:String,
){
}

object ModelDatosPublicacion{
    val publicacion: List<ModelPublicaciones> = listOf(
        ModelPublicaciones("Sebas","Loaiza","hola", "que hace","https://static.eldiario.es/clip/ab74aa95-3656-424c-8ca1-dce590aabb97_16-9-discover-aspect-ratio_default_0.jpg"),
        ModelPublicaciones("Juan","Sabogal","Super Publicacion ", "prueba publicacion","https://motollopis.es/wp-content/uploads/2021/09/GSXR1000-1024x676.jpg")
    )
}