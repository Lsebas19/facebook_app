package com.example.facebook

import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.PopupWindow
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentManager
import com.example.facebook.MainActivity.Iniciada
import com.example.facebook.databinding.ActivityInicioBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.facebook.adapter.PublicacionesAdapter
import com.example.facebook.models.ModelDatosPublicacion
import com.example.facebook.models.ModelPublicaciones
import com.example.facebook.models.PublicacionViewModel

class InicioActivity : AppCompatActivity() {

    private lateinit var fragmentManager: FragmentManager
    private lateinit var bindingInicio : ActivityInicioBinding
    private lateinit var fragmentActual : Fragment
    object ContadorFragments{
        var contadorCrear = 0
        var contadorModificar = 0
        var todos = 0
    }
    object Mostrar{
        lateinit var publicacion: ModelPublicaciones
        var posicion:Int = 0
    }

    object Modificar{
        lateinit var publi: ModelPublicaciones

    }
    object ModificarPosicion{
        var posicion: Int = 0
    }

    val publicacionViewModel: PublicacionViewModel by viewModels()
    lateinit var publicacionAdapter : PublicacionesAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        bindingInicio = ActivityInicioBinding.inflate(layoutInflater)
        setContentView(bindingInicio.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        Log.d("papotico", "${ModelDatosPublicacion.publicacion}")

        //inicializar funciones
        listarPublicacion()
        initRecyclerView()
        observeViewModel()
        mostrar()
        eventos()
    }

    private fun listarPublicacion() {
        publicacionViewModel.addPublicacionList(ModelDatosPublicacion.publicacion.toMutableList())

    }

    //esta seria la funcion a la que llama desde el fragment de agregar y recibe sus datos
    fun agregarPubli(nombre:String, apellido:String, titulo:String, descripcion:String, imagen:String){
        val publicacion = ModelPublicaciones(
            nombre,
            apellido,
            titulo,
            descripcion,
            imagen
        )
        publicacionViewModel.addPublicacion(publicacion)
    }
    //esta seria la funcion a la que llama desde el fragment de modificar y recibe sus datos
    fun modificarPubli(nombre:String, apellido:String, titulo:String, descripcion:String, imagen:String,position:Int){
        val publicacion = ModelPublicaciones(
            nombre,
            apellido,
            titulo,
            descripcion,
            imagen
        )

        publicacionViewModel.updatePublicacion(position,publicacion)
    }
    //la funcion que inicializa el recycler
    private fun initRecyclerView() {
        publicacionAdapter = PublicacionesAdapter(
            publicacionViewModel.dataListPublicacion.value?: mutableListOf(),
            // al dar el click en el item ejecuta una funcion mandandole las dos variables para modificar
            onUpdateClick = {
                selectPublicacion,position ->
                //esta es la funcion que ejecuta
                actualiza(selectPublicacion,position)
            },
            onDeleteClick ={position ->
                val inflater = LayoutInflater.from(this)
                val vista_emergente = inflater.inflate(R.layout.activity_borrar_publicacion,null)

                val popup_ventana = PopupWindow(vista_emergente, ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, true)
                popup_ventana.isOutsideTouchable = false  //evita que la ventana se cierre al tocar afuera de esta

                popup_ventana.showAtLocation(vista_emergente, Gravity.CENTER,0,0)

                val botonCerrarVentana =  vista_emergente.findViewById<ImageButton>(R.id.boton_cancelar)
                val botonAceptar = vista_emergente.findViewById<ImageButton>(R.id.boton_aceptar)
                botonCerrarVentana.setOnClickListener {
                    popup_ventana.dismiss()
                }
                botonAceptar.setOnClickListener {
                    elimina(position)
                    popup_ventana.dismiss()
                }

            },
            onShowClick = { selectPublicacion,position ->
                mostrar(selectPublicacion,position)
            }
            )

        bindingInicio.recyclerview.layoutManager = LinearLayoutManager(this)

        bindingInicio.recyclerview.adapter = publicacionAdapter
    }
    //el observador de el recycler, el que esta pendiente a cambios que se hagan
    private fun observeViewModel() {
        publicacionViewModel.dataListPublicacion.observe(this, Observer{publi ->
            publicacionAdapter.publicacion = publi
            publicacionAdapter.notifyDataSetChanged()})
    }
    //muestra los datos de la cuenta iniciada en la pestaña principal
    private fun mostrar(){
        bindingInicio.nombreCuenta.text = Iniciada.cuenta_iniciada[0][2]
        bindingInicio.descripcion.text =Iniciada.cuenta_iniciada[0][0]
        bindingInicio.apellidoCuenta.text = Iniciada.cuenta_iniciada[0][3]
    }
    private fun lauchFragment(fragment:Fragment){
        fragmentActual= fragment
        fragmentManager = supportFragmentManager
        if (ContadorFragments.todos < 1) {
            if (ContadorFragments.contadorCrear < 1) {
                ContadorFragments.todos = ContadorFragments.todos + 1
                ContadorFragments.contadorCrear = ContadorFragments.contadorCrear + 1
                fragmentManager.beginTransaction().add(R.id.fragmentContent, fragment).commit()
            }
        }
    }

    fun eventos(){
        // evento para cerrar sesion
        bindingInicio.cerrarSesion.setOnClickListener {
            Iniciada.cuenta_iniciada.removeAt(0)
            finish()
        }
        //evento para llamar al fragment de crear publicacion
        bindingInicio.agregar.setOnClickListener {
            lauchFragment(CrearPublicacionFragment())
        }


    }
    //funcion que llama al fragment de actualizar publicacion
    fun fragmentActualizar(fragment:Fragment){
        fragmentManager = supportFragmentManager
        if (ContadorFragments.todos < 1) {
            if (ContadorFragments.contadorModificar < 1) {
                ContadorFragments.todos = ContadorFragments.todos + 1
                ContadorFragments.contadorModificar = ContadorFragments.contadorModificar + 1
                fragmentManager.beginTransaction().add(R.id.fragmentContent, fragment).commit()
            }
        }
    }
    fun fragmentMostrarPublicacion(fragment:Fragment){
        fragmentManager = supportFragmentManager
        if (ContadorFragments.todos < 1) {

            ContadorFragments.todos = ContadorFragments.todos + 1
            fragmentManager.beginTransaction().add(R.id.fragmentContent, fragment).commit()

        }
    }


    /* al no poder mandar los datos al fragment cree esta funcion que guarda los dos datos necesarios para actualizar
    una publicacion en un object para luego rescatarlos en el fragment y de una vez llama al fragment
    */
    fun actualiza(selectPubli: ModelPublicaciones, position:Int){
        Modificar.publi = selectPubli
        ModificarPosicion.posicion = position
        fragmentActualizar(ModificarPublicacionFragment())
    }
    fun elimina(position:Int){
        publicacionViewModel.removerPublicacion(position)
    }
    fun mostrar(selectPubli: ModelPublicaciones, position: Int){
        Mostrar.publicacion = selectPubli
        Mostrar.posicion = position
        fragmentMostrarPublicacion(PublicacionFragment())
    }
}


