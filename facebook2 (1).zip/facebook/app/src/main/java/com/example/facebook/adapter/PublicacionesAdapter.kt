package com.example.facebook.adapter



import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.facebook.R
import com.example.facebook.databinding.ActivityItemPublicacionesBinding
import com.example.facebook.models.ModelPublicaciones

class PublicacionesAdapter(var publicacion: List<ModelPublicaciones>,
    private val onUpdateClick: (ModelPublicaciones, Int) -> Unit,
    private val onDeleteClick: (Int) -> Unit, private val onShowClick: (ModelPublicaciones, Int) -> Unit,
    ): RecyclerView.Adapter<PublicacionesAdapter.PublicacionesViewHolder>(){

    class PublicacionesViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val binding = ActivityItemPublicacionesBinding.bind(view)
        fun inicializa(publicacion: ModelPublicaciones,
                       onUpdateClick:(ModelPublicaciones,Int) -> Unit,
                       onDeleteClick: (Int) -> Unit,
                       onShowClick:(ModelPublicaciones,Int) -> Unit){
            binding.nombrePublicacion1.text = publicacion.nombrePublicacion
            binding.apellidoPublicacion1.text = publicacion.apellidoPublicacion
            binding.tituloPublicacion1.text = publicacion.tituloPublicacion


            //Al dar click en cualquier parte del item
            binding.editarPublicacion.setOnClickListener {
                onUpdateClick(publicacion, getLayoutPosition())
            }
            binding.borrarPublicacion.setOnClickListener {
                onDeleteClick(getLayoutPosition())
                true
            }
            binding.mostrarPublicacion.setOnClickListener {
                onShowClick(publicacion, getLayoutPosition())
            }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PublicacionesViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_item_publicaciones, parent,false)
        return PublicacionesViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: PublicacionesViewHolder,
        position: Int
    ) {
        holder.inicializa(publicacion[position],onUpdateClick, onDeleteClick,onShowClick)
    }

    //funcion que cuenta las publicaciones que tiene el recycler
    override fun getItemCount() = publicacion.size


}