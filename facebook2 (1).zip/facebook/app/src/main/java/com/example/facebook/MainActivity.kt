package com.example.facebook

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.facebook.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var bindingIniciarSesion : ActivityMainBinding
    object Lista {var cuentas = mutableListOf(mutableListOf<String>("juansebas1920@gmail.com", "1902", "Sebastian","Loaiza"), mutableListOf<String>("carlosanl1609@gmail.com", "1609", "Carlos","loaiza"))}
    object Iniciada {var cuenta_iniciada: MutableList<MutableList<String>> = mutableListOf() }
    var miLista = Lista.cuentas
    lateinit var mostrarContra : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        bindingIniciarSesion = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bindingIniciarSesion.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inicializa()
        eventos()

        mostrarContra()

    }
    override fun onResume() {
        super.onResume()
        bindingIniciarSesion.usuarioIniciar.text?.clear()
        bindingIniciarSesion.contrasenaIniciar.text?.clear()
        if (RegistroActivity.Registrando.registrado.size > 0){
            bindingIniciarSesion.usuarioIniciar.setText(RegistroActivity.Registrando.registrado[0]).toString()
        }
    }
    fun inicializa(){
        mostrarContra = "false"
    }

    fun eventos(){
        bindingIniciarSesion.iniciarSesionBoton.setOnClickListener{
            // si el codigo encuentra que hay una cuenta iniciada a la hora de presionar el boton este la cierra
            if (Iniciada.cuenta_iniciada.size == 1) {
                Iniciada.cuenta_iniciada.removeAt(0)
            }

            // cada que se presione el boton los bordes de los editText se vuelven a su estado normal
            bindingIniciarSesion.usuario1.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bindingIniciarSesion.contraseA1.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)

            // aqui se inicializan variables para usar despues y tambien se recolectan datos de los editText
            val user = bindingIniciarSesion.usuarioIniciar.text.toString()
            val contra = bindingIniciarSesion.contrasenaIniciar.text.toString()
            var contadorUsuarios:Int = miLista.size-1
            var igual = ""
            var numCuenta = 0

            //esta primera validacion es para saber si el campo usuario está vacio
            if (user == ""){
                Toast.makeText(this, "campo correo vacio", Toast.LENGTH_SHORT).show()
                bindingIniciarSesion.usuario1.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
            }else {
                // validacion para saber si el campo contraseña está vacio
                if (contra == "") {
                    Toast.makeText(this, "campo contraseña vacio", Toast.LENGTH_SHORT).show()
                    bindingIniciarSesion.contraseA1.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                }else {
                    // este for recorre la instancia de lista de cuentas para validar si el usuario y contraseña son correctos
                    for (i in 0..contadorUsuarios) {
                        if (miLista[i][0] == user) {
                            if (miLista[i][1] == contra) {
                                igual = "SI"
                                numCuenta = i
                            }
                        }
                    }

                    // esta validacion es para saber si los datos coincidieron con alguna cuenta
                    if (igual == "SI"){
                        //aqui se guarda la cuenta que va a estar iniciada
                        Iniciada.cuenta_iniciada.add(miLista[numCuenta]).toString()

                        launchInicio()

                    }
                    else{
                        Toast.makeText(this, "credenciales incorrectas", Toast.LENGTH_SHORT).show()

                        launchCrearCuenta(user)
                    }
                }
            }
        }
        // el evento que se lanza cuando se presiona el boton crear cuenta
        bindingIniciarSesion.crearCuentaLogin.setOnClickListener{
            var user=""
            launchCrearCuenta(user)
        }
    }
    fun mostrarContra(){
        bindingIniciarSesion.iconoContraL.setOnClickListener {
            if (mostrarContra == "false"){
                mostrarContra = "true"
                bindingIniciarSesion.contrasenaIniciar.inputType = InputType.TYPE_CLASS_TEXT
                bindingIniciarSesion.iconoContraL.setImageResource(R.drawable.ic_mostrar_contra)

            }
            else{
                mostrarContra = "false"
                bindingIniciarSesion.contrasenaIniciar.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                bindingIniciarSesion.iconoContraL.setImageResource(R.drawable.ic_ocultar_contra)
            }
            val textoActual = bindingIniciarSesion.contrasenaIniciar.text
            bindingIniciarSesion.contrasenaIniciar.setSelection(textoActual?.length ?:0)
        }
    }

    private fun launchCrearCuenta(user:String) {
        val intent = Intent(this, RegistroActivity::class.java)
        intent.putExtra("USUARIO", user)
        startActivity(intent)
    }

    private fun launchInicio(){
        val intent = Intent(this, InicioActivity::class.java)
        startActivity(intent)
    }
}