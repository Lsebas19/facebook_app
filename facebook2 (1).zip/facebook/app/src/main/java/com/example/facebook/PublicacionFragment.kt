package com.example.facebook

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.facebook.InicioActivity.ContadorFragments
import com.example.facebook.databinding.FragmentPublicacionBinding
import com.example.facebook.models.ModelPublicaciones
import com.squareup.picasso.Picasso


class PublicacionFragment : Fragment() {
    private var  _bindingMostrar: FragmentPublicacionBinding? = null
    private val bindingMostrar get() = _bindingMostrar!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _bindingMostrar = FragmentPublicacionBinding.inflate(inflater,container,false)
        return bindingMostrar.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        evento(view)
        mostrarPublicacion(InicioActivity.Mostrar.publicacion, InicioActivity.Mostrar.posicion)
    }

    fun evento(view:View){
        bindingMostrar.cerrarPublicacionM.setOnClickListener{
            ContadorFragments.todos = 0
            parentFragmentManager.beginTransaction().hide(this).commit()
        }
    }
    fun mostrarPublicacion(publicacion: ModelPublicaciones,posicion:Int){
        bindingMostrar.nombrePublicacionM.setText(publicacion.nombrePublicacion)
        bindingMostrar.apellidoPublicacion1.setText(publicacion.apellidoPublicacion)
        bindingMostrar.tituloPublicacionM.setText(publicacion.tituloPublicacion)
        bindingMostrar.descripcionPublicacionM.setText(publicacion.descripcionPublicacion)
        Picasso.get()
            .load(publicacion.imagenPublicacion)
            .into(bindingMostrar.imagenPublicacionM)
    }

}