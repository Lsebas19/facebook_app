package com.example.facebook.models

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class PublicacionViewModel : ViewModel() {
    private val _dataListPublicacion: MutableLiveData<MutableList<ModelPublicaciones>> =
        MutableLiveData(mutableListOf())

    val dataListPublicacion: MutableLiveData<MutableList<ModelPublicaciones>> get() = _dataListPublicacion

    fun addPublicacionList(mPublicacion : MutableList<ModelPublicaciones>){
        val currentList = dataListPublicacion.value ?: mutableListOf()
        currentList.addAll(mPublicacion)
        dataListPublicacion.postValue(currentList)
    }

    //funcion para añadir publicacion
    fun addPublicacion(mPublicacion : ModelPublicaciones){
        val currentList = dataListPublicacion.value ?: mutableListOf()
        currentList.add(mPublicacion)
        dataListPublicacion.postValue(currentList)
    }

    //funcion para actualizar la publicacion
    fun updatePublicacion(position: Int ,mPublicacion : ModelPublicaciones){
        val currentList = dataListPublicacion.value ?: mutableListOf()
        currentList.set(position,mPublicacion)
        dataListPublicacion.postValue(currentList)
    }
    fun removerPublicacion(position: Int){
        val currentList = dataListPublicacion.value ?: mutableListOf()
        currentList.removeAt(position)
        dataListPublicacion.postValue(currentList)
    }


}