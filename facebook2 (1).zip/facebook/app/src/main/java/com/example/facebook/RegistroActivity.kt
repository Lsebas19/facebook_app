package com.example.facebook

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.PopupWindow
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.facebook.MainActivity.Lista
import com.example.facebook.databinding.RegistroActivityBinding

class RegistroActivity : AppCompatActivity() {
    private lateinit var bindingRegistro: RegistroActivityBinding
    lateinit var usuarioIniciar: String
    val miLista = Lista.cuentas
    lateinit var mostrarContra : String
    object Registrando {
        var registrado: MutableList<String> = mutableListOf<String>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        bindingRegistro = RegistroActivityBinding.inflate(this.layoutInflater)
        setContentView(bindingRegistro.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        inicializar()
        evento()
        mostrar()
        eliminar()
        mostrarContrasena()

    }


    fun inicializar() {
        usuarioIniciar = intent.getStringExtra("USUARIO").toString()
        mostrarContra = "false"
    }

    private fun mostrar() {

        //se coloca el usuario introducido en login al ser erroneo para ahorrar tiempo
        if (usuarioIniciar != "null"){
            bindingRegistro.usuarioCrear.setText(usuarioIniciar).toString()
        }
    }

    fun evento() {
        bindingRegistro.crearCuentaBoton.setOnClickListener {
            //hace que los bordes de los editText sean los predeterminados a la hora de presionar el boton de crear cuenta
            bindingRegistro.usuarioC.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bindingRegistro.nombreC.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bindingRegistro.apellidosC.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bindingRegistro.confirmarcontraseAC.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)
            bindingRegistro.contraseAC.background = ContextCompat.getDrawable(this,R.drawable.bordes_login)

            //inicializa variables y obtiene los datos de los editText para la validacion de estos
            var user = bindingRegistro.usuarioCrear.text.toString()
            var contrasena1 = bindingRegistro.contraseACrear.text.toString()
            var confirmarC = bindingRegistro.confirmarContraseACrear.text.toString()
            var nombreU = bindingRegistro.nombreCrear.text.toString()
            var apellidosU = bindingRegistro.apellidosCrear.text.toString()
            var contador:Int = miLista.size-1
            var igual= ""

            // valida que el usuario no esté vacio
            if (user == ""){
                Toast.makeText(this, "campo correo vacio", Toast.LENGTH_SHORT).show()
                bindingRegistro.usuarioC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
            }else {
                // valida que el nombre no esté vacio
                if (nombreU == "") {
                    Toast.makeText(this, "campo nombre vacio", Toast.LENGTH_SHORT).show()
                    bindingRegistro.nombreC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                } else {
                    //valida que el campo apellidos no esté vacio
                    if (apellidosU == ""){
                        Toast.makeText(this, "campo apellidos vacio", Toast.LENGTH_SHORT).show()
                        bindingRegistro.apellidosC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                    }
                    else {
                        //valida que el campo contraseña no esté vacio
                        if (contrasena1 == "") {
                            Toast.makeText(this, "campo contraseña vacio", Toast.LENGTH_SHORT)
                                .show()
                            bindingRegistro.contraseAC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                        } else {
                            // valida que el usuario tenga el formato de correo
                            if (user.endsWith("@gmail.com") || user.endsWith("@outlook.com") || user.endsWith("@yahoo.com")|| user.endsWith("@hotmail.com") || user.endsWith("@live.com") ) {

                                // busca que el usuario del editText concuerde con algun usuario de la lista de cuentas
                                for (i in 0..contador) {
                                    if (miLista[i][0] == user) {
                                        igual = "SI"
                                    }
                                }
                                //valida si se encontro el usuario
                                if (igual == "SI") {
                                    Toast.makeText(this, "usuario ya existe", Toast.LENGTH_SHORT)
                                        .show()
                                    bindingRegistro.usuarioC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)

                                } else {
                                    // valida que la contraseña y la confirmacion sean la misma
                                    if (confirmarC != contrasena1) {
                                        Toast.makeText(
                                            this,
                                            "las contraseñas no coinciden",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        bindingRegistro.contraseAC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                                        bindingRegistro.confirmarcontraseAC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)

                                    } else {
                                        //crea una variable para guardar todos esos datos dados en editText en una mutableList para guardarlos en la lista de cuentas
                                        var cuenta_creada =
                                            mutableListOf(user, contrasena1, nombreU,apellidosU)
                                        miLista.add(cuenta_creada)

                                        //el codigo para llamar la ventana emergente
                                        val inflater = LayoutInflater.from(this)
                                        val vista_emergente = inflater.inflate(R.layout.activity_ventana_emergente_registro,null)

                                        val popup_ventana = PopupWindow(vista_emergente, ViewGroup.LayoutParams.MATCH_PARENT,
                                            ViewGroup.LayoutParams.MATCH_PARENT, true)
                                        popup_ventana.isOutsideTouchable = false  //evita que la ventana se cierre al tocar afuera de esta

                                        popup_ventana.showAtLocation(vista_emergente, Gravity.CENTER,0,0)

                                        val botonCerrarVentana =  vista_emergente.findViewById<Button>(R.id.boton_ventana)
                                        botonCerrarVentana.setOnClickListener {
                                            if (Registrando.registrado.size > 0){
                                                Registrando.registrado.removeAt(0)
                                            }
                                            Registrando.registrado.add(user)
                                            finish()
                                        }
                                        //termina el codigo para llamar ventana emergente
                                    }

                                }
                            } else {
                                Toast.makeText(
                                    this,
                                    "este no es un correo valido",
                                    Toast.LENGTH_SHORT
                                ).show()
                                bindingRegistro.usuarioC.background = ContextCompat.getDrawable(this,R.drawable.campo_vacio)
                            }

                        }
                    }
                }
            }
        }

        //el evento de cancelar la creacion de cuenta
        bindingRegistro.cancelar.setOnClickListener {
            finish()
        }

    }
    fun eliminar(){
        bindingRegistro.xIconoApellido.setOnClickListener{
            bindingRegistro.apellidosCrear.setText("")
        }
        bindingRegistro.xIconoNombre.setOnClickListener{
            bindingRegistro.nombreCrear.setText("")
        }
    }

    fun mostrarContrasena(){

        bindingRegistro.iconoContra.setOnClickListener {
            if (mostrarContra == "false"){
                mostrarContra = "true"
                bindingRegistro.contraseACrear.inputType = InputType.TYPE_CLASS_TEXT
                bindingRegistro.iconoContra.setImageResource(R.drawable.ic_mostrar_contra)

            }
            else{
                mostrarContra = "false"
                bindingRegistro.contraseACrear.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                bindingRegistro.iconoContra.setImageResource(R.drawable.ic_ocultar_contra)
            }
            val textoActual = bindingRegistro.contraseACrear.text
            bindingRegistro.contraseACrear.setSelection(textoActual?.length ?:0)
        }

        bindingRegistro.iconoContraConfirmar.setOnClickListener {
            if (mostrarContra == "false"){
                mostrarContra = "true"
                bindingRegistro.confirmarContraseACrear.inputType = InputType.TYPE_CLASS_TEXT
                bindingRegistro.iconoContraConfirmar.setImageResource(R.drawable.ic_mostrar_contra)

            }
            else{
                mostrarContra = "false"
                bindingRegistro.confirmarContraseACrear.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                bindingRegistro.iconoContraConfirmar.setImageResource(R.drawable.ic_ocultar_contra)
            }
            val textoActual = bindingRegistro.confirmarContraseACrear.text
            bindingRegistro.confirmarContraseACrear.setSelection(textoActual?.length ?:0)
        }

    }


}